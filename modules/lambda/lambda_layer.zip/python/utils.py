"""
Utility functions for Lambda functions
"""

def format_response(status_code, body):
    """
    Format a standard API Gateway response
    
    Parameters:
    status_code (int): HTTP status code
    body (dict): Response body
    
    Returns:
    dict: Formatted response
    """
    import json
    
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body)
    }

def s3_helper():
    """
    Helper function for S3 operations
    
    Returns:
    object: S3 client
    """
    import boto3
    return boto3.client('s3')

def log_event(event, logger):
    """
    Log an event with proper formatting
    
    Parameters:
    event (dict): Event to log
    logger (Logger): Logger instance
    """
    import json
    logger.info(f"Event received: {json.dumps(event, default=str)}")