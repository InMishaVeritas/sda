# Lambda Layer for scan-ia-gen Project

This Lambda Layer contains common utility functions and libraries used by the Lambda functions in the scan-ia-gen project.

## Contents

- `python/utils.py`: Utility functions for Lambda functions
  - `format_response`: Format a standard API Gateway response
  - `s3_helper`: Helper function for S3 operations
  - `log_event`: Log an event with proper formatting

## Usage

This layer is attached to the Lambda functions in the project. To use the utilities in a Lambda function:

```python
# Import utilities from the layer
from utils import format_response, s3_helper, log_event

def lambda_handler(event, context):
    # Use the utilities
    s3 = s3_helper()
    log_event(event, logger)
    
    # Return a formatted response
    return format_response(200, {"message": "Success"})
```