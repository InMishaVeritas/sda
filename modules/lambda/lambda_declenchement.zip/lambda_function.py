import json
import boto3
import os

def lambda_handler(event, context):
    """
    Lambda function to trigger the Step Functions state machine
    
    Parameters:
    event (dict): Event data from S3
    context (object): Lambda context
    
    Returns:
    dict: Response with status and message
    """
    try:
        # Initialize Step Functions client
        sfn_client = boto3.client('stepfunctions')
        
        # In a real implementation, you would get the state machine ARN from environment variables
        # and extract the S3 event details to pass to the state machine
        state_machine_arn = "arn:aws:states:region:account-id:stateMachine:MyStateMachine"
        
        # Extract S3 event information
        if 'Records' in event and len(event['Records']) > 0:
            s3_record = event['Records'][0]['s3']
            bucket_name = s3_record['bucket']['name']
            object_key = s3_record['object']['key']
            
            # Prepare input for the state machine
            input_data = {
                "bucket": bucket_name,
                "key": object_key,
                "executionId": context.aws_request_id
            }
            
            # Start execution of the state machine
            response = sfn_client.start_execution(
                stateMachineArn=state_machine_arn,
                name=f"Execution-{context.aws_request_id}",
                input=json.dumps(input_data)
            )
            
            return {
                'statusCode': 200,
                'body': json.dumps(f'Successfully started state machine execution: {response["executionArn"]}')
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Invalid event structure: No S3 records found')
            }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error starting state machine execution: {str(e)}')
        }