import json
import boto3
import os
import zipfile
from io import BytesIO

def lambda_handler(event, context):
    """
    Lambda function to unzip and extract content from archive in S3
    
    Parameters:
    event (dict): Event data
    context (object): Lambda context
    
    Returns:
    dict: Response with status and message
    """
    try:
        # Get the bucket name from environment variable
        bucket_name = os.environ.get('BUCKET_NAME')
        
        # Get the object key from the event
        # In a real implementation, you would extract this from the event
        object_key = "example_archive.zip"
        
        # Initialize S3 client
        s3_client = boto3.client('s3')
        
        # Download the zip file
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        zip_obj = response['Body'].read()
        
        # Process the zip file
        buffer = BytesIO(zip_obj)
        z = zipfile.ZipFile(buffer)
        
        # Extract and upload each file in the zip
        for filename in z.namelist():
            file_content = z.read(filename)
            
            # Upload extracted file to S3
            s3_client.put_object(
                Bucket=bucket_name,
                Key=f"extracted/{filename}",
                Body=file_content
            )
        
        return {
            'statusCode': 200,
            'body': json.dumps('Successfully extracted zip file')
        }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error extracting zip file: {str(e)}')
        }